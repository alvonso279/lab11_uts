# lab11web
# REST API dengan POSTMAN

![Screenshot (149)](https://github.com/ristof5/lab11web/assets/116700466/fe2e0d59-e016-4c92-becb-c45c398f5bb4)

![Screenshot (150)](https://github.com/ristof5/lab11web/assets/116700466/af30ef04-a313-4fa5-9e03-76938693ef6c)

![Screenshot (151)](https://github.com/ristof5/lab11web/assets/116700466/1ad451c6-dea2-4139-9fa5-c75c61fd5941)
